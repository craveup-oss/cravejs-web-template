# Changelog

## 2.1.0-catalog.0

- Exposes revision-aware catalog change acceptance and catalog revalidation evidence for the canonical managed runtime.
- Bundles public declarations generated from the executable commerce contract owner, with no runtime dependencies.
- Retains the v2 customer login and menu request contract.

## 2.0.1

### Documentation and ecosystem

- Clarifies production, sandbox, and local API-origin configuration without adding an in-app
  environment switch or changing the SDK security model.
- Documents the TypeScript and Dart/Flutter Storefront SDKs as equivalent clients for the same
  Storefront API, while keeping package installation and platform guidance explicit.
- Improves the npm README and documentation links. The runtime API and wire contract are unchanged
  from 2.0.0.

## 2.0.0

### Breaking contract

- Removes the legacy browser API-key contract. Public catalog reads are anonymous; customer actions
  use customer JWTs; carts and receipts use scoped capabilities.
- Replaces the legacy client surface with the direct Storefront API contract, caller-owned cart
  session persistence, revision-aware mutations, explicit idempotency, checkout recovery, customer,
  receipt, rating, analytics, and loyalty operations.
- Uses one strict v2 request contract: canonical fulfillment methods, dedicated order-time updates,
  canonical decimal strings, and canonical CLI configuration names have no legacy adapters.
- Requires Node.js 20 or newer for Node-based development and server-side usage.

### Security

- Strips caller-provided API-key and authorization headers before applying SDK-owned credentials.
- Requires HTTPS for every non-loopback `baseUrl`; plain HTTP remains available only on exact
  loopback development hosts.
- Redirect responses are rejected rather than forwarding a customer JWT or scoped capability to a target.
- Rejects empty or dot-segment resource identifiers before URL parsing can normalize a request into
  a different Storefront operation.
- Applies the request timeout while resolving async `getAuthToken` providers as well as during the
  network request.
- Keeps capability storage under application control and avoids retaining URLs, headers, request
  bodies, tokens, or client secrets in SDK errors.
- Publishes from an exact commit and tag after registry-collision, package-content, reproducibility,
  type-resolution, and clean-consumer gates. Public npm provenance remains unavailable while the
  canonical source repository is private.

### Developer experience and package size

- Supports typed ESM, CommonJS, Next.js, and Expo/React Native resolution.
- Adds anonymous `locations.getOrderingReadiness()` so consumers can check a fulfillment method
  without creating a cart.
- Serializes async session-store mutations per location and keeps stored cart revisions monotonic;
  concurrent ordering-session starts are coalesced or serialized within one client instance.
- Replaces an unchanged stale hosted-checkout session after a successful handoff exchange without
  overwriting a genuinely newer session created while the exchange was in flight.
- Has zero runtime dependencies and declares itself side-effect free for tree shaking.
- Removes duplicated declaration maps from the package while retaining complete declarations.

### License

The package is publicly downloadable from npm but is `UNLICENSED`. Public registry access does not
grant permission to copy, modify, or redistribute the package. CraveUp must make a separate legal
decision before advertising this SDK as open source.
