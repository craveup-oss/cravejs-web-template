# CraveUp Storefront SDK

Typed, framework-neutral client for the public Crave Storefront API. It connects browsers, Next.js applications, and React Native/Expo applications directly to `/api/v1/storefront` without a BFF or browser API key.

```bash
npm install --save-exact @craveup/storefront-sdk@2.0.1
```

Version 2 is a new major contract. If you use SDK 1.x, follow the [1.x to 2.0.0 upgrade guide](https://docs.craveup.com/guides/upgrade-guide) instead of changing the version in place.

## Choose the SDK for your platform

Both official packages use the same Storefront API contract and security model. Choose the package
that matches your application runtime:

| Platform | Package | Use it for |
| --- | --- | --- |
| TypeScript/JavaScript | `@craveup/storefront-sdk` | Browsers, Next.js, React, Node.js, and React Native/Expo |
| Dart/Flutter | [`crave_storefront_sdk`](https://pub.dev/packages/crave_storefront_sdk) | Flutter mobile, web, and desktop applications |

MCP servers and other Node.js integrations should use this TypeScript package. Applications own
their session persistence and user interface; neither SDK embeds a storefront UI.

## Environments

Use a separate client configuration and separate credentials/session storage for each deployment:

| Environment | API origin |
| --- | --- |
| Production | `https://api.craveup.com` |
| Sandbox | The exact sandbox API origin provided for your Crave account |
| Local development | An exact loopback origin such as `http://localhost:4000` |

Sandbox and production are separate deployments with separate environment variables and data. Set
`baseUrl` from the deployment configuration, and namespace persisted carts, customer sessions, and
receipt capabilities by that exact origin. Do not add a runtime production-to-sandbox switch to a
production storefront or reuse a token/session across environments.

## Security model

- `baseUrl` is always explicit. The SDK never infers an environment from a credential.
- Remote `baseUrl` values must use HTTPS. Plain HTTP is accepted only for the exact loopback hosts
  `localhost`, `127.0.0.1`, and `[::1]`; a LAN address such as `192.168.x.x` is not loopback.
- Redirect responses are rejected instead of followed, so credentials and cart capabilities
  cannot cross an origin through a redirect.
- Caller-controlled resource identifiers are encoded as one path segment, and exact dot segments
  are rejected before URL normalization can change the intended operation.
- The SDK has no API-key option and removes the legacy browser key header from caller-provided headers.
- Customer JWTs come from `getAuthToken` and are sent only in `Authorization`.
- Guest cart capabilities and revisions live in a caller-owned `StorefrontSessionStore`.
- Receipt capabilities are call-scoped and sent only as `X-Receipt-Token`.
- Published merchant, location, menu, product, distance, order-time, and gratuity calls never receive the customer JWT.
- The public client exposes the exact typed method surface only; raw transport is not exported.
- Errors expose status, public code, request ID, safe details, method, and route template. They do not retain URLs, headers, bodies, tokens, or client secrets.

## Setup

```ts
import {
  createStorefrontClient,
  type StorefrontCartSession,
  type StorefrontSessionStore,
} from "@craveup/storefront-sdk";

const apiOrigin = "https://api.craveup.com";
const environmentNamespace = new URL(apiOrigin).origin;
const merchantSlug = "downtown-pizza";
const cartKey = (locationId: string) =>
  `${environmentNamespace}|${merchantSlug}|${locationId}`;
const sessions = new Map<string, StorefrontCartSession>();

const sessionStore: StorefrontSessionStore = {
  get(locationId) {
    return sessions.get(cartKey(locationId)) ?? null;
  },
  set(session) {
    sessions.set(cartKey(session.locationId), session);
  },
  clear(locationId) {
    sessions.delete(cartKey(locationId));
  },
};

let customerSessionJwt: string | null = null;

export const storefront = createStorefrontClient({
  baseUrl: apiOrigin,
  getAuthToken: () => customerSessionJwt,
  sessionStore,
});
```

The application decides how to persist sessions. Scope every cart record by a canonical API environment, merchant, and location. Scope customer JWTs by environment and merchant, and receipt capabilities by environment, merchant, and receipt ID. The SDK never selects `localStorage`, cookies, SecureStore, or URL parameters itself.

Within one client instance, session-store mutations are serialized per location. Async adapters are
supported, revisions are persisted monotonically, identical concurrent ordering-session starts are
coalesced, and different starts for the same location are serialized. This coordination does not
span separate client instances or processes, so share one client per application session or provide
that coordination in the storage adapter.

- Browser apps should use versioned, tab-scoped `sessionStorage`, never `localStorage`.
- React Native/Expo apps should use `expo-secure-store` with dot-delimited keys containing only SecureStore-safe characters. Validate or encode every dynamic key component.
- Clear a guest cart capability after claim, cart deletion, expiry, or terminal checkout handling. Keep the numeric revision if a claimed cart still needs customer-authenticated access.
- Clear the merchant-scoped JWT on logout. Remove a receipt capability after terminal display or expiry.

Do not share a browser client with server code. Create a server client with no session store and no auth-token provider, and use it only for anonymous published calls:

```ts
export const storefrontServerClient = createStorefrontClient({
  baseUrl: process.env.NEXT_PUBLIC_CRAVEUP_API_URL!,
});

const merchant = await storefrontServerClient.merchant.getBySlug(
  "downtown-pizza",
);
```

Before deploying a browser storefront, register its exact browser origin—including scheme, hostname, and non-default port—with Crave. Wildcard origins are not supported. Native apps usually omit the browser `Origin` header and do not need browser CORS registration.

## Ordering and carts

Check availability without creating a cart before showing an ordering action:

```ts
const readiness = await storefront.locations.getOrderingReadiness(
  locationId,
  "takeout",
);
if (!readiness.ready) showOrderingUnavailable(readiness.reason);
```

`locations.getOrderingReadiness()` is an anonymous, side-effect-free GET. Its fulfillment method
defaults to `takeout` when omitted.

Starting an ordering session stores the returned guest capability and ETag revision. Cart mutations
automatically attach `X-Cart-Token`, `If-Match`, and a generated `Idempotency-Key`. Cart-scoped
analytics automatically uses the same capability and rejects fabricated cart references.
Cloudflare and other transforming edges may return the same opaque revision tag with a standard
`W/` prefix; the API accepts either the exact strong or weak wrapper and still compares the numeric
cart or address revision atomically.

```ts
const { cart } = await storefront.orderingSessions.start(locationId, {
  fulfillmentMethod: "takeout",
  marketplaceId: "web",
});

await storefront.cart.addItem(locationId, cart.id, {
  productId,
  quantity: 1,
  itemUnavailableAction: "remove_item",
  selections: [],
});
```

Supply your own idempotency key when an application-level retry must reuse the exact operation:

```ts
await storefront.cart.updateGratuity(
  locationId,
  cart.id,
  { percentage: "15" },
  { idempotencyKey: "checkout-gratuity-0001" },
);
```

Claiming a guest cart requires both its capability and the customer JWT. After a successful claim, the SDK clears the guest capability from the session store.

## Customer, checkout, receipts, and loyalty

```ts
const challenge = await storefront.customer.login({
  merchantSlug: "downtown-pizza",
  identifierString: "+15551234567",
});

const { token } = await storefront.customer.verifyOtp({
  merchantSlug: "downtown-pizza",
  identifierString: "+15551234567",
  methodId: challenge.methodId,
  otp: "123456",
});
customerSessionJwt = token;

const paymentSession = await storefront.checkout.createPaymentSession(
  locationId,
  cart.id,
  { includeCustomerContext: true },
);
if (paymentSession.provider === "STRIPE") {
  console.log(paymentSession.clientSecret);
} else {
  console.log(paymentSession.applicationId, paymentSession.locationId);
}
const result = await storefront.checkout.getOrderResult(locationId, cart.id);

const receipt = await storefront.receipts.get(receiptId, {
  receiptToken,
});

const loyalty = await storefront.loyalty.ledger(locationId, { limit: 25 });
await storefront.loyalty.claims.submit({
  orderId,
  reason: "missing_points",
  note: "Points did not appear after the order.",
});
```

Persist `token` through the same environment-and-merchant-scoped adapter used by `getAuthToken`; never use a public environment variable. Login and OTP calls themselves are anonymous, while customer, order, address, saved-payment, and loyalty-history methods require the merchant-bound JWT.

`includeCustomerContext: true` opts a signed-in shopper's guest-capability cart
into customer-aware discount validation or Stripe customer association. Omit it
for guest operations. Once a cart is claimed and its guest capability is
cleared, the SDK uses the customer JWT automatically.

The SDK surface also includes published menus/products/location data, analytics, all cart mutations, customer profile/orders/addresses/saved payments/logout, rating submission, loyalty quote/redeem/cancel, and claim status.

## Errors

```ts
import {
  StorefrontApiError,
  StorefrontClientStateError,
  StorefrontProtocolError,
  StorefrontTimeoutError,
} from "@craveup/storefront-sdk";

try {
  await storefront.cart.get(locationId, cartId);
} catch (error) {
  if (error instanceof StorefrontApiError) {
    console.error(error.status, error.code, error.requestId);
    if (error.retryAfterMs !== undefined) scheduleRetry(error.retryAfterMs);
  } else if (error instanceof StorefrontClientStateError) {
    console.error(error.code);
  } else if (error instanceof StorefrontProtocolError) {
    console.error(error.reason, error.method, error.routeTemplate);
  } else if (error instanceof StorefrontTimeoutError) {
    showRetryMessage();
  }
}
```

`StorefrontClientStateError` fails locally before an invalid request is sent;
for example, `CUSTOMER_AUTH_REQUIRED` means the customer JWT is missing.
`StorefrontProtocolError` distinguishes an empty successful response from
invalid JSON without retaining response content. `StorefrontApiError.retryAfterMs`
contains the bounded server retry delay when one is supplied. `CART_CONFLICT`
is surfaced as a normal typed error. The SDK never silently retries a mutation;
refresh the cart, reconcile the new revision, and ask the user to retry when
appropriate.

`getAuthToken` resolution uses the same timeout as the network response. `defaultTimeoutMs` and a
per-call `timeoutMs` cover the whole SDK attempt; if the async token provider does not settle before
the deadline, the SDK throws `StorefrontTimeoutError` without sending the request.

## Navigation-only redirect

`GET /locations/{locationId}/redirect` is a navigation-only REST endpoint and is intentionally not
wrapped by the SDK. Navigate a browser or native in-app browser to that URL directly when entering
the hosted storefront; do not fetch it as JSON through the Storefront client. SDK transport rejects
redirect responses and never follows them.

## Support

- Read the [Storefront SDK documentation](https://docs.craveup.com/getting-started/storefront-sdk).
- Building with Flutter? Read the [Dart/Flutter SDK documentation](https://docs.craveup.com/getting-started/flutter-storefront-sdk).
- Email [hello@craveup.com](mailto:hello@craveup.com).
- Ask in the [Crave Slack community](https://join.slack.com/t/cravejscommunity/shared_invite/zt-3hfr081io-aYuLC3n6gBFKQuho0HrTng).

## License

This package is marked `UNLICENSED`, and its canonical source repository is
private. Availability on npm or in public documentation does not grant
permission to copy, modify, or redistribute the package. Contact
[hello@craveup.com](mailto:hello@craveup.com) with licensing questions.

## Development

```bash
pnpm --filter @craveup/storefront-sdk test
pnpm --filter @craveup/storefront-sdk check-types
pnpm --filter @craveup/storefront-sdk lint
pnpm --filter @craveup/storefront-sdk build
```
